import { useParams } from "react-router-dom";
import ProductList from "../Components/Product/ProductList";


const ProductDetails = () => {

    const params = useParams();
    
    const url = 'https://fakestoreapi.com/products/' + params.productId;

    return(
        <ProductList url = {url}/>
    );
}

export default ProductDetails;