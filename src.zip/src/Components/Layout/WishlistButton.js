import './WishlistButton.css';

const WishlistButton = () => {
    return(
        <button className='wishlist-button'>
            <span id= 'text'> Wishlist </span>
        </button>
    )
}

export default WishlistButton;