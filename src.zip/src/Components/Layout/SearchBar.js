import './SearchBar.css'
import SearchButton from './SearchButton';
import React, { useEffect, useState} from 'react'
const SearchBar = () => {

    const clickButtonHandler = () => {
        console.log("Search button Clicked");
    }
    const Url = "https://fakestoreapi.com/products";
    const [copydata, setCopyData] = useState([]);

    const chanegData = (e) => {
        let getchangedata = e.toLowerCase();

        if (getchangedata == "") {
            setCopyData(Url );
        } else {
            let storedata = Url .filter((ele, k) => {
                return ele.title.toLowerCase().match(getchangedata);
            });

            setCopyData(storedata)
        }
    }
    return(
        <form>
        <div className='searchBar-container'>
            <input type="text"    onChange={(e) => chanegData(e.target.value)}/>
        </div>
        {/* <div className='new-expense__actions'>
          <button type = "submit" onClick={clickButtonHandler}>
              submit
          </button> */}
        {/* </div> */}
      </form>
    );
}

export default SearchBar;