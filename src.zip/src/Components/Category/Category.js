import { useState } from "react";
import ProductList from "../Product/ProductList";
import CategoryFilter from "./CategoryFilter";

const Category = ({getFilterValue}) => {

    return(
        <CategoryFilter  />
    );
}

export default Category;

